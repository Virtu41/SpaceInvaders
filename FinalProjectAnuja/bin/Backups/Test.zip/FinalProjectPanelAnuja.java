import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
//Anuja Perera
//ICS3U1 Final Project

public class FinalProjectPanelAnuja extends JPanel implements KeyListener, ActionListener, MouseListener  {
	//Variables 
	String txt="";
	int xOfPlayer=460, yOfPlayer=625;  //coordinates of player 
	
	ArrayList<Integer> listInvaderX = new ArrayList<Integer>();
	ArrayList<Integer> listInvaderY = new ArrayList<Integer>();
	int [] bulletX = {-10, -10, -10};
	int [] bulletY = {-10, -10, -10};
	int [] invaderBulletX = {-10, -10, -10, -10};
	int [] invaderBulletY = {-10, -10, -10, -10};
	int score = 0;  
	JButton b1, b2, b3, b4 ;     //declare 4 buttons
	JLabel lblImg;
	boolean running = false; 
	ImageIcon playImg, rules, bg, spaceInvader, logo, player, start, bullet, invaderBullet, howToPlay, gameover, book, amongUS, amongUS2, win ;      //ImageIcon to store images
	Rectangle invaderBulletBox, playerBox, playerBulletBox, spaceInvaderBox; 
	Timer timer; 
	int timercounter = 0; 
	
	public FinalProjectPanelAnuja(){    // constructor
		this.setLayout(null); 
		// load images
		listInvaderX.add(250); 
		listInvaderX.add(250); 
		listInvaderX.add(250); 
		listInvaderX.add(250); 
		listInvaderX.add(475); 
		listInvaderX.add(475); 
		listInvaderX.add(475); 
		listInvaderX.add(475);
		listInvaderX.add(700);
		listInvaderX.add(700);
		listInvaderX.add(700);
		listInvaderX.add(700);
		 
		listInvaderY.add(150);
		listInvaderY.add(250);
		listInvaderY.add(350);
		listInvaderY.add(450);
		listInvaderY.add(150);
		listInvaderY.add(250);
		listInvaderY.add(350);
		listInvaderY.add(450);
		listInvaderY.add(150);
		listInvaderY.add(250);
		listInvaderY.add(350);
		listInvaderY.add(450);
		win = new ImageIcon ("Win.png");
		amongUS2 = new ImageIcon("AmongUs2.png");
		amongUS = new ImageIcon("AmongUs.png");
		book = new ImageIcon ("Book.png");
		playImg = new ImageIcon("play_100_100.png");
		rules = new ImageIcon("Rules.png");
		bg = new ImageIcon("bg2.png");
		spaceInvader = new ImageIcon("SpaceInvader.png");
		timer = new Timer(30, this);
		howToPlay = new ImageIcon ("HowToPlay.png"); 
		logo =new ImageIcon("Logo.png");
		player = new ImageIcon("Gun.png");
		start = new ImageIcon("Start.png");
		bullet = new ImageIcon("Bullet.png"); 
		invaderBullet = new ImageIcon("InvaderBullet.png");
		gameover = new ImageIcon ("GameOver.png"); 
		//set button 1 
		b1 = new JButton(start); 
		b1.setBounds(40, 420, 100, 100);
		this.add(b1);
		b1.addActionListener(this);
		b1.addKeyListener(this);
		
		//set button b2 
		b2= new JButton(book);
		b2.setBounds(40, 190, 100, 100);
		this.add(b2);
		b2.addActionListener(this);
		b2.addKeyListener(this);
		
		b4= new JButton(rules);
		b4.setBounds(40, 570, 100, 100);
		this.add(b4);
		b4.addActionListener(this);
		b4.addKeyListener(this);

		//set button b3  
		b3= new JButton("Exit Button");
		b3.setBounds(40, 340, 100, 30);// x, y, width, height
		this.add(b3);
		b3.addActionListener(this);
		b3.addKeyListener(this);
		//set button lblAnimated
		lblImg=new JLabel(logo);  //img instead of text
		lblImg.setBounds(5, 5, 160, 120);// x, y, width, height
		this.add(lblImg);
		

		addKeyListener( this );  // add key listener to the panel
		addMouseListener( this );  // add mouse listener to the panel
		timer.start();
	}// end of constructor


	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(bg.getImage(), 0, 0, 900, 800, null);  // paint background
		g.setFont(new Font("SansSerif", Font.BOLD, 28)); 	// set a new font
		Color purple = new Color(102, 0 , 153);
		g.setColor(purple);
		g.drawString("Welcome to Space Invaders",310,30);   // display the string starting at the coordinate (100, 200)
		g.drawString(txt,400,20);   // display the string starting at the coordinate (100, 200)
		g.drawImage(player.getImage(), xOfPlayer, yOfPlayer, 90, 70,null);//(img, x, y, width, height, observer)
		g.setFont(new Font("SansSerif", Font.BOLD, 20));
		g.drawString("Score: " + score , 460, 100);
		g.drawString(txt, 100, 50);
		Color yellow = new Color(255,255,0);
		g.setColor(yellow);
		g.drawString("RULES", 60, 555);
		g.drawString(txt, 100, 50);
		g.drawString("CONTROLS", 35, 175);
		g.setColor(purple);
		g.drawImage(amongUS.getImage(), 720, 19, null);
		g.drawImage(amongUS2.getImage(), 190, 20, null);
		for (int i =0; i<5; i++) {
			g.drawRect(150 + i, 120 + i, 700, 600); // X Y  width height  
		}
		g.setColor(Color.red);
		for (int i =0; i<listInvaderX.size(); i++) {
			g.drawImage(spaceInvader.getImage(), listInvaderX.get(i), listInvaderY.get(i), 60, 64, null);
		}
		
		for (int i =0; i<bulletX.length; i++) {
			if (bulletX[i] > -10) {
			g.drawImage (bullet.getImage(),bulletX[i], bulletY[i], 15, 45, null); 
			}
		}
		for (int i =0; i<invaderBulletX.length; i++) {
			g.drawImage(invaderBullet.getImage(), invaderBulletX[i],invaderBulletY[i], 16, 36, null); 
		}
		/*
		for (int i =0; i<invaderBulletX.length; i++) {
			g.drawRect(invaderBulletX[i]+2,invaderBulletY[i], 10, 36); 
		}
		for (int i =0; i<listInvaderX.size(); i++) {
			g.drawRect(listInvaderX.get(i)+5,listInvaderY.get(i)+5, 47, 50); 
		}
		for (int i =0; i<bulletX.length; i++) {
			g.drawRect(bulletX[i]+3,bulletY[i], 8,40); 
		}
		g.drawRect(xOfPlayer+25,yOfPlayer, 40,67); 
		*/ 
			
		
		
	}//end of paint   

	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1) {
			running = true; 
		}
		
		if (e.getSource()==b2) {
		JOptionPane.showMessageDialog(null, "", "How to Play", JOptionPane.NO_OPTION, howToPlay);	
		}
		
		if (e.getSource()==b4) {
			JOptionPane.showMessageDialog(null, "<html> <font size=5, face='Arial' color='red'> Rules/Controls: </font> <br> 1. Use the A and D keys for Movement <br> 2. Use the R key to shoot the invaders(You have to let go of the key) <br> <u> you only have 3 bullets </u> <br> 3. Avoid getting shot by the invaders  <br> 4. You can not move and shoot at the same time <b></b> <br>5. You can hit the invaders bullets with your bullets <br></html>", "Rules",JOptionPane.INFORMATION_MESSAGE ); 
		}
		
		if (e.getSource()==b3){
			JOptionPane.showMessageDialog(null, "That was an exit button. \n Good Bye", "My exit message",JOptionPane.WARNING_MESSAGE ); 
			System.exit(0);
		}
		// avoid long lines 
		// make appropriate variable names 
		
		if (running) {
			if (e.getSource() == timer ) { 
				timercounter++; 
				timercounter = timercounter % 1000000; 
				if (timercounter % 4 == 0) {
					moveInvaders(); 
				}
				moveBullets(); 
				moveInvaderBullet(); 
				repaint(); 
				bulletcheck(); 
				checkWin(); 
				
			}
		}
	}
	public void checkWin () {
		if (score == 12) {
			JOptionPane.showMessageDialog(null, "", "You Won", JOptionPane.NO_OPTION, win);	
			System.exit(0);
		}
	}
	public void moveInvaders () {
	for (int i =0; i<listInvaderX.size(); i++) {
			int randomX = (int)(Math.random()*2)+1;
			int randomY = (int)(Math.random()*10)+1;
			int random = (int) (Math.random()*10)+1; 
			for (int j=0; j<random; j++) {
				if (randomX == 1 && listInvaderX.get(i) < 700) {
					listInvaderX.set(i, listInvaderX.get(i) + 3);  
				}
				if (randomX == 2 && listInvaderX.get(i) > 160) {
					listInvaderX.set(i, listInvaderX.get(i)- 3); 
						
				}
				else if (randomY == 1 && listInvaderY.get(i) > 120) {
					listInvaderY.set(i, listInvaderY.get(i) - 3); 
						
				}
				else if (randomY == 2 && listInvaderY.get(i) < 500) {
					listInvaderY.set(i, listInvaderY.get(i) + 4); 
						
				}

				
			}
		}
	}
	public void moveBullets () {
		for (int i =0; i<bulletX.length; i++) {
			if (bulletX[i] != -10) {
			bulletY[i] -= 10;  
			}
			if (bulletY[i] < 120) {
				bulletX[i] = -10;
				bulletY[i] = -10;
			}
		} 
	}
	
	public void moveInvaderBullet () {
		for (int i=0; i<invaderBulletX.length; i++) {
			if (invaderBulletX[i] == -10) {
				int random = (int)(Math.random()*(listInvaderX.size()));
				invaderBulletX[i] = listInvaderX.get(random) + 25;
				invaderBulletY[i] = listInvaderY.get(random) + 10;
				break;						
			}
		}
		for (int i =0; i<invaderBulletX.length; i++) {
			if (invaderBulletX[i] != -10) {
				invaderBulletY[i] +=  3;
			}
			if (invaderBulletY[i] > 700) {
				invaderBulletX[i] = -10;
				invaderBulletY[i] = -10;
			}
					
		}
	}
	public void bulletcheck() {
		
		for (int i=0; i<invaderBulletX.length; i++) {
			invaderBulletBox = new Rectangle(invaderBulletX[i],invaderBulletY[i], 16,36);
			 
			playerBox=new Rectangle(xOfPlayer+25,yOfPlayer, 40,67); 
			if (invaderBulletBox.intersects(playerBox)) {
				JOptionPane.showMessageDialog(null, "", "GameOver", JOptionPane.NO_OPTION, gameover);
				System.exit(0);
			}
			
			
		}
		
		
		for (int i=0; i<bulletX.length; i++) {
			playerBulletBox = new Rectangle (bulletX[i],bulletY[i], 8,35); 
				for (int j=0; j<listInvaderX.size(); j++) {
					spaceInvaderBox = new Rectangle (listInvaderX.get(j)+5,listInvaderY.get(j)+5, 47, 50);
					if (playerBulletBox.intersects(spaceInvaderBox)) {
					score++;  
					listInvaderX.remove(j);
					listInvaderY.remove(j);
					
					bulletX [i] = -10;
					bulletY [i] = -10; 
					if (j != 0) {
						j--; 
					}
				
					}
					
				}
		}
		for (int i=0; i<invaderBulletX.length; i++) {
			invaderBulletBox = new Rectangle(invaderBulletX[i],invaderBulletY[i], 16,36);
			for (int j =0; j<bulletX.length; j++)  {
				playerBulletBox = new Rectangle (bulletX[j],bulletY[j], 8,35); 
				if (playerBulletBox.intersects(invaderBulletBox)) {
					invaderBulletX[i] = -10; 
					invaderBulletY[i] = -10;
					bulletX [j]  = -10; 
					bulletY [j]  = -10; 
					
				}
			}
		}
	}
	
	public void keyTyped(KeyEvent e) {}

	public void keyPressed(KeyEvent e) {
		if (running) {
			if(e.getKeyCode() == 65 && xOfPlayer > 150) { // if left arrow is clicked
				xOfPlayer -=10; 
				repaint(); 
			}
			else if(e.getKeyCode() == 68 && xOfPlayer < 762) { // if right arrow is clicked
				xOfPlayer +=10; 
				repaint(); 
			}
		}
		
	}
	public void shooting () {
		for (int i =0; i<bulletX.length; i++) {
				if (bulletX[i] == -10) {
					bulletX[i] = xOfPlayer + 36;
					bulletY[i] = yOfPlayer - 20; 
					break;					
					}
				}
	}
	public void keyReleased(KeyEvent e) {
		if (running) {
			if (e.getKeyCode() == 82) {
				shooting(); 
			}
			
		}
	}
	public void mouseClicked(MouseEvent e) {}
	

	public void mousePressed(MouseEvent e) {}

	public void mouseReleased(MouseEvent e) {}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public static void main(String[] args) {
		JFrame f = new JFrame("Final Project Anuja");//java JFrame object

		Container cont = f.getContentPane();  // get container - top of the frame
		cont.setLayout(new BorderLayout());  // set Layout to Border 

		FinalProjectPanelAnuja bp= new FinalProjectPanelAnuja();  // create an object of our game panel
		cont.add(bp, BorderLayout.CENTER ); // add this game panel to the center of the frame

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // make frame closed when x button is pressed
		f.setVisible(true);     // make the frame visible
		f.setSize(900, 800);  // set the size of the frame

	}//end of main
}//end of class