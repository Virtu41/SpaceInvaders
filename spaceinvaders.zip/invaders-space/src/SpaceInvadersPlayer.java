import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;


public class SpaceInvadersPlayer implements KeyListener, ActionListener {
	SpaceInvaders gui;
	public SpaceInvadersPlayer(SpaceInvaders in) {
		// TODO Auto-generated constructor stub
		gui = in;
	}
	public void keyTyped(KeyEvent e) {}

	public void keyPressed(KeyEvent e) {
		// Check if game is running and see what button the user clicked 
		
	}
	// Move the player bullets 
	public void shooting () {
	
	}
	
	// Check if the shoot button is pressed 
	public void keyReleased(KeyEvent e) {

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
	}
	public void add(JButton b1) {
		// TODO Auto-generated method stub
		
	}
	

}
