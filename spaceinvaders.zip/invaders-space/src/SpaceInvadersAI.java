import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

public class SpaceInvadersAI implements ActionListener {
	SpaceInvaders gui;
	public SpaceInvadersAI(SpaceInvaders in) {
		// TODO Auto-generated constructor stub
		gui = in;
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
	}
	

}
